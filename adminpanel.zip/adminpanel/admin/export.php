<?php
session_start();
$server = "localhost";
$username = "root";
$password = "";
$dbname = "cee_db";

// Create connection
$conn = new mysqli($server, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$host = "localhost";
$user = "root";
$pass = "";
$db   = "cee_db";
$con = null;

try {
    $con = new PDO("mysql:host={$host};dbname={$db};", $user, $pass);
} catch (Exception $e) {
}

// Filename for the CSV
$filename = 'Exam_Results_' . date('Y-m-d') . '.csv';

// Function to get the table name based on exam_id
function getTableName($exam_id)
{
    switch ($exam_id) {
        case '1':
            return 'quantitativequestion';
        case '2':
            return 'logicalquestion';
        case '3':
            return 'verbalquestion';
        case '4':
            return 'technicalquestion';
        default:
            return 'exam_question_tbl';
    }
}

$exam_id = $_GET['exam'];
$tableName = getTableName($exam_id);

$selEx = $con->query("SELECT * FROM exam_tbl WHERE ex_id='$exam_id' ")->fetch(PDO::FETCH_ASSOC);

$exam_course = $selEx['cou_id'];
$exam_title = $selEx['ex_title'];

$getcid = $con->query("SELECT * FROM course_tbl WHERE cou_id='$exam_course' ")->fetch(PDO::FETCH_ASSOC);
$get_exam_course = $getcid['cou_code'];


$selExmne = $con->query("SELECT * FROM examinee_tbl et ");
$sno = 0;
$Id = 1;

$array = array();
$file = fopen($filename, "w");

// Add headers to the CSV file
$array = array("S.No", "REGISTER NO", "NAME", "COURSE CODE", "COURSE NAME", "SCORE", "PERCENTAGE");
fputcsv($file, $array);

while ($selExmneRow = $selExmne->fetch(PDO::FETCH_ASSOC)) {
    $exmneId = $selExmneRow['exmne_id'];
    $tableName = getTableName($exam_id);

    $selScore = $con->query("SELECT * FROM $tableName eqt INNER JOIN exam_answers ea ON eqt.eqt_id = ea.quest_id AND eqt.exam_answer = ea.exans_answer WHERE ea.axmne_id='$exmneId' AND ea.exam_id='$exam_id' AND ea.exans_status='new' ORDER BY ea.exans_id DESC");

    $selAttempt = $con->query("SELECT * FROM exam_attempt WHERE exmne_id='$exmneId' AND exam_id='$exam_id' ");
    $over = $selEx['ex_questlimit_display'];
    $score = $selScore->rowCount();
    $ans = $score / $over * 100;
    $selExmneRow['exmne_rnumber'];
    $selExmneRow['exmne_fullname'];
    
    if ($selAttempt->rowCount() == 0) {
        $totScore = "Not answer yet";
    } else if ($selScore->rowCount() > 0) {
        $totScore = $selScore->rowCount();
    } else {
        $totScore = $selScore->rowCount();
    }

    if ($selAttempt->rowCount() == 0) {
        $percentage = "Not answer yet";
    } else {
        $percentage = number_format($ans, 2) . "%";
        
    }

   
    $sno++;
    $RegisterNumber =  $selExmneRow['exmne_rnumber'];
    $Name =  $selExmneRow['exmne_fullname'];
    
    $array = array($sno, $RegisterNumber, $Name, $get_exam_course, $exam_title, $totScore, $percentage);
    fputcsv($file, $array);

    $Id++;
   
}

fclose($file);

header("Content-Description: File Transfer");
header("Content-Disposition: attachment; filename=$filename");
header("Content-Type: application/csv;");
header("Expires: 0");
header("Cache-Control: must-revalidate");
header("Pragma: public");
header("Content-Length: " . filesize($filename));

// Read the file and output it to the user
readfile($filename);

// Delete the file after sending it to the user
unlink($filename);
exit();

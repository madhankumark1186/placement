<?php 
 include("../../../conn.php");


extract($_POST);
$selExamineeRnumber = $conn->query("SELECT * FROM examinee_tbl WHERE exmne_rnumber='$rnumber' ");
$selExamineeFullname = $conn->query("SELECT * FROM examinee_tbl WHERE exmne_fullname='$fullname' ");
$selExamineeEmail = $conn->query("SELECT * FROM examinee_tbl WHERE exmne_email='$email' ");


if($code == "0")
{
	$res = array("res" => "noCode");
}
else if($course == "0")
{
	$res = array("res" => "noCourse");
}
else if($year_level == "0")
{
	$res = array("res" => "noLevel");
}
else if($mobile == "0")
{
	$res = array("res" => "noMobile");
}
else if($selExamineeRnumber->rowCount() > 0)
{
	$res = array("res" => "regsiternumberExist", "msg" => $rnumber);
}
else if($selExamineeFullname->rowCount() > 0)
{
	$res = array("res" => "fullnameExist", "msg" => $fullname);
}
else if($selExamineeEmail->rowCount() > 0)
{
	$res = array("res" => "emailExist", "msg" => $email);
}
else
{
	$insData = $conn->query("INSERT INTO examinee_tbl(exmne_rnumber,exmne_fullname,exmne_code,exmne_course,exmne_year_level,exmne_email,exmne_mobile,exmne_password) VALUES('$rnumber','$fullname','$code','$course','$year_level','$email','$mobile','$password')  ");
	if($insData)
	{
		$res = array("res" => "success", "msg" => $email);
	}
	else
	{
		$res = array("res" => "failed");
	}
}


echo json_encode($res);
 ?>
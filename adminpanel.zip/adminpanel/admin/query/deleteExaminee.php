<?php 
 include("../../../conn.php");


extract($_POST);

$deleteEx = $conn->query("DELETE  FROM examinee_tbl WHERE exmne_id='$id'  ");
if($delCourse)
{
	$res = array("res" => "success");
}
else
{
	$res = array("res" => "failed");
}



	echo json_encode($res);
 ?>
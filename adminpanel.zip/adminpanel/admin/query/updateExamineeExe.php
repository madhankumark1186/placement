<?php
 include("../../../conn.php");
 extract($_POST);


$updCourse = $conn->query("UPDATE examinee_tbl SET exmne_rnumber='$exrnumber', exmne_fullname='$exFullname',exmne_code='$exCode', exmne_course='$exCourse',exmne_year_level='$exYrlvl', exmne_email='$exEmail', exmne_mobile='$exMobile', exmne_password='$exPass' WHERE exmne_id='$exmne_id' ");
if($updCourse)
{
	   $res = array("res" => "success", "exFullname" => $exFullname);
}
else
{
	   $res = array("res" => "failed");
}



 echo json_encode($res);	
?>
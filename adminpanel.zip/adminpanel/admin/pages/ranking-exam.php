<div class="app-main__outer">
    <div class="app-main__inner">
        <?php 
            try {
                @$exam_id = $_GET['exam_id'];
                
                // Function to get the table name
                if (!function_exists('getTableName')) {
                    function getTableName($exam_id) {
                        switch ($exam_id) {
                            case '1':
                                return 'exam_question_tbl';
                            case '2':
                                return 'logicalquestion';
                            case '3':
                                return 'verbalquestion';
                            case '4':
                                return 'technicalquestion';
                            default:
                                return 'exam_question_tbl';
                        }
                    }
                }

                if ($exam_id != "") {
                    $selEx = $conn->query("SELECT * FROM exam_tbl WHERE ex_id='$exam_id' ")->fetch(PDO::FETCH_ASSOC);
                    if ($selEx) {
                        $exam_course = $selEx['cou_id'];
                        $exam_title = $selEx['ex_title'];

                        $getcid = $conn->query("SELECT * FROM course_tbl WHERE cou_id='$exam_course' ")->fetch(PDO::FETCH_ASSOC);
                        $get_exam_course = $getcid['cou_code'];
                        
                        $selExmne = $conn->query("SELECT * FROM examinee_tbl et ");
                        ?>
                        <div class="app-page-title">
                            <div class="page-title-wrapper">
                                <div class="page-title-heading">
                                    <div><b class="text-primary">RANKING BY EXAM</b><br>
                                        Exam Name : <?php echo $selEx['ex_title']; ?><br><br>
                                    </div>
                                   
                                    <div class="modal-footer">
                                        <a href="export.php?exam=<?php echo $exam_id; ?>">
                                        <button type="print" class="btn btn-primary">Print Result</button>
                                        </a>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table class="align-middle mb-0 table table-borderless table-striped table-hover" id="tableList">
                                <tbody>
                                    <thead>
                                        <tr>
                                            <th>S.No</th>
                                            <th>REGISTER NO</th>
                                            <th>NAME</th>
                                            <th>COURSE CODE</th>
                                            <th>COURSE NAME</th>
                                            <th>SCORE</th>
                                            <th>PERCENTAGE</th>
                                        </tr>
                                    </thead>
                                    <?php 
                                        $sno = 1;
                                        while ($selExmneRow = $selExmne->fetch(PDO::FETCH_ASSOC)) {
                                            $exmneId = $selExmneRow['exmne_id'];
                                            $tableName = getTableName($exam_id);

                                            $selScore = $conn->query("SELECT * FROM $tableName eqt INNER JOIN exam_answers ea ON eqt.eqt_id = ea.quest_id AND eqt.exam_answer = ea.exans_answer WHERE ea.axmne_id='$exmneId' AND ea.exam_id='$exam_id' AND ea.exans_status='new' ORDER BY ea.exans_id DESC");

                                            $selAttempt = $conn->query("SELECT * FROM exam_attempt WHERE exmne_id='$exmneId' AND exam_id='$exam_id' ");
                                            $over = $selEx['ex_questlimit_display'];
                                            $score = $selScore->rowCount();
                                            $ans = $score / $over * 100;
                                            ?>
                                            <tr style="<?php 
                                                if ($selAttempt->rowCount() == 0) {
                                                    echo "background-color: #E9ECFF;color:black";
                                                } else if ($ans >= 90) {
                                                    echo "background-color: #F9F0F0;color:black";
                                                } else if ($ans >= 75) {
                                                    echo "background-color: #F9F0F0;color:black";
                                                } else if ($ans >= 50) {
                                                    echo "background-color: #F9F0F0;color:black";
                                                } else {
                                                    echo "background-color: #F9F0F0;color:black";
                                                }
                                                ?>">
                                                <td><?php echo $sno++; echo "."; ?></td>
                                                <td><?php echo $selExmneRow['exmne_rnumber']; ?></td>
                                                <td><?php echo $selExmneRow['exmne_fullname']; ?></td>
                                                <td><?php echo $get_exam_course; ?></td>
                                                <td><?php echo $exam_title; ?></td>
                                                <td>
                                                    <?php 
                                                        if ($selAttempt->rowCount() == 0) {
                                                            echo "Not answer yet";
                                                        } else if ($selScore->rowCount() > 0) {
                                                            echo $totScore = $selScore->rowCount();
                                                        } else {
                                                            echo $totScore = $selScore->rowCount();
                                                        }
                                                    ?>
                                                </td>
                                                <td>
                                                    <?php 
                                                        if ($selAttempt->rowCount() == 0) {
                                                            echo "Not answer yet";
                                                        } else {
                                                            echo number_format($ans, 2) . "%";
                                                        }
                                                    ?>
                                                </td>
                                            </tr>
                                        <?php }
                                    ?>                              
                                </tbody>
                            </table>
                        </div>
                    <?php 
                    } else {
                        echo "<div class='alert alert-danger'>Exam not found.</div>";
                    }
                } else { ?>
                    <div class="app-page-title">
                        <div class="page-title-wrapper">
                            <div class="page-title-heading">
                                <div><b>RANKING BY EXAM</b></div>
                            </div>
                        </div>
                    </div> 
                    <div class="col-md-12">
                        <div class="main-card mb-3 card">
                            <div class="card-header">EXAM List</div>
                            <div class="table-responsive">
                                <table class="align-middle mb-0 table table-borderless table-striped table-hover" id="tableList">
                                    <thead>
                                        <tr>
                                            <th class="text-left pl-4">Exam Title</th>
                                            <th class="text-left">Course</th>
                                            <th class="text-left">Description</th>
                                            <th class="text-center" width="8%">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                            $selExam = $conn->query("SELECT * FROM exam_tbl ORDER BY ex_id DESC");
                                            if ($selExam->rowCount() > 0) {
                                                while ($selExamRow = $selExam->fetch(PDO::FETCH_ASSOC)) { ?>
                                                    <tr>
                                                        <td class="pl-4"><?php echo $selExamRow['ex_title']; ?></td>
                                                        <td>
                                                            <?php 
                                                                $courseId = $selExamRow['cou_id'];
                                                                $selCourse = $conn->query("SELECT * FROM course_tbl WHERE cou_id='$courseId'");
                                                                while ($selCourseRow = $selCourse->fetch(PDO::FETCH_ASSOC)) {
                                                                    echo $selCourseRow['cou_name'];
                                                                }
                                                            ?>
                                                        </td>
                                                        <td><?php echo $selExamRow['ex_description']; ?></td>
                                                        <td class="text-center">
                                                            <a href="?page=ranking-exam&exam_id=<?php echo $selExamRow['ex_id']; ?>" class="btn btn-success btn-sm">View</a>
                                                        </td>
                                                    </tr>
                                                <?php }
                                            } else { ?>
                                                <tr>
                                                    <td colspan="5">
                                                        <h3 class="p-3">No Exam Found</h3>
                                                    </td>
                                                </tr>
                                            <?php }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php }
            } catch (Exception $e) {
                echo "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
            }
        ?>      
    </div>
</div>
